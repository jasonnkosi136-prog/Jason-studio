export default function App() {
  return (
    <div style={{fontFamily:'Arial',background:'#000',color:'#fff',minHeight:'100vh',padding:'40px'}}>
      <h1 style={{fontSize:'48px'}}>Jason Studio</h1>
      <p style={{fontSize:'20px',maxWidth:'700px'}}>
        Professional websites for businesses in South Africa and beyond.
      </p>

      <div style={{marginTop:'30px'}}>
        <a
          href="https://wa.me/27670766580"
          target="_blank"
          style={{
            background:'#25D366',
            color:'#fff',
            padding:'15px 25px',
            borderRadius:'12px',
            textDecoration:'none',
            fontWeight:'bold'
          }}
        >
          WhatsApp Jason Studio
        </a>
      </div>

      <section style={{marginTop:'60px'}}>
        <h2>Services</h2>
        <ul>
          <li>Business Websites</li>
          <li>Online Stores</li>
          <li>Website Redesigns</li>
          <li>Booking Systems</li>
        </ul>
      </section>

      <section style={{marginTop:'60px'}}>
        <h2>Contact</h2>
        <p>Website: jasonstudio.co.za</p>
        <p>Mobile: 067 076 6580</p>
        <p>Hosting Platform: Vercel.com</p>
      </section>
    </div>
  );
}
